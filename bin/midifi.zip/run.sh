java -jar midifi.jar
