java -jar midifi.jar setup
