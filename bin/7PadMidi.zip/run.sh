java -jar 7PadMidi.jar $*
